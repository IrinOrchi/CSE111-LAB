import java.util.Scanner;
public class Task3
{
public static void main(String []args )
{
Scanner sc=new Scanner(System.in);
int []a=new int[5];
for(int j=0;j<=a.length-1;j++)
{
System.out.println("Enter a number:");
a[j]=sc.nextInt();
}

int max=a[0];
int min=a[0];
int minPosition=0;
int maxPosition=0;
for(int i=1;i<=a.length-1;i++)
{
if (a[i]>max)
{
max=a[i];
maxPosition=i;
}
}
for(int k=1;k<=a.length-1;k++)
{
if (a[k]<min)
{
min=a[k];
minPosition=k;
}
}
System.out.println("The smallest number "+ min + " was found at "+ minPosition);
System.out.println("The largest number "+ max + " was found at "+ maxPosition);
}
}