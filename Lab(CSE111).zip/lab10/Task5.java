import java.util.Scanner;
public class Task5
{
public static void main(String []args )
{
Scanner sc=new Scanner(System.in);
int []a=new int[5];
for(int i=0;i<=a.length-1;i++)
{
System.out.println("Enter a number:");
a[i]=sc.nextInt();
}
for(int k=0;k<a.length;k++)
{
int largest=k;

for(int m=k+1;m<=a.length-1;m++)
{
if (a[m]>a[largest])
{largest=m;}
}
int backup=a[k];
a[k]= a[largest];
a[largest]=backup;
}
for(int j=0;j<=a.length-1;j++)
System.out.print(a[j]+",");
}
}