import java.util.Scanner;
public class Task6
{
public static void main(String []args )
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter a number:");
int n=sc.nextInt();
int []a=new int[n];
for(int i=0;i<=a.length-1;i++)
{
System.out.println("Enter a number:");
a[i]=sc.nextInt();
}
for(int k=0;k<a.length;k++)
{
int largest=k;
int m;
for( m=k+1;m<=a.length-1;m++)
{
if (a[m]>a[largest])
{largest=m;}
}
int backup=a[k];
a[k]= a[largest];
a[largest]=backup;
}
int g;
int h;
if(n%2!=0)
{
g=(n-1)/2;
System.out.println(a[g]);
}
else
{
g=(n/2)-1;
h=(n/2);
float mid=(a[g]+a[h])/2;
System.out.println(mid);
}
}
}