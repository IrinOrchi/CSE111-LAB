import java.util.Scanner;
public class Task1
{
public static void main(String []args )
{
Scanner sc=new Scanner(System.in);
int []a=new int[5];
for(int j=0;j<=a.length-1;j++)
{
System.out.println("Enter a number:");
a[j]=sc.nextInt();
}
int max=0;
max=a[0];
for(int i=1;i<=a.length-1;i++)
{
if (a[i]>max)
{max=a[i];}
}
System.out.println("Largest mark is "+max);
}
}