import java.util.Scanner;
public class Task9
{
public static void main(String []args )
{
Scanner sc=new Scanner(System.in);
int []a=new int[15];
int []valueCounterA=new int[10];
for(int i=0;i<=a.length-1;i++)
{
System.out.println("Enter a number:");
int n=sc.nextInt();
valueCounterA[n]= valueCounterA[n]+1;
}
for(int i=0;i<=valueCounterA.length-1;i++)
{
System.out.println(i +" was given "+valueCounterA[i]+" time(s)");
}
}
}