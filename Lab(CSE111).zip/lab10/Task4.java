import java.util.Scanner;
public class Task4
{
public static void main(String []args )
{
Scanner sc=new Scanner(System.in);
int []a=new int[5];
for(int i=0;i<=a.length-1;i++)
{
System.out.println("Enter a number:");
a[i]=sc.nextInt();
}
for(int k=0;k<a.length;k++)
{
int smallest=k;
int m;
for( m=a.length-1;m>=k+1;m--)
{
if (a[m]<a[smallest])
{smallest=m;}
}
int backup=a[k];
a[k]= a[smallest];
a[smallest]=backup;
}
for(int j=0;j<=a.length-1;j++)
System.out.print(a[j]+",");
}
}