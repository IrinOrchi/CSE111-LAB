import java.util.Scanner;
public class Task2
{
public static void main(String []args )
{
Scanner sc=new Scanner(System.in);
int []a=new int[5];
for(int j=0;j<=a.length-1;j++)
{
System.out.println("Enter a number:");
a[j]=sc.nextInt();
}
int max=0;
int i;
int m=a[0];
for( i=1;i<=a.length-1;i++)
{
if (a[i]>m)
{
max=i;
m=a[i];
}
}
System.out.println("The largest number "+ m + " was found at "+ max);
}
}